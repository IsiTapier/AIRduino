/*
 SubMenu.cpp - SubMenu-Library for Librarys.
*/

#include "SubMenu.h"

extern int _pages;
extern int _currentPage;
extern int _defaultPage;
extern String _title;
extern MenuPage pages[];

extern SubMenu(String title, int numberPages, int currentPage, int defaultPage) {

}

extern void init() {

}

extern void handleTouch(TSPoint p) {
  if(!checkTouch(p)) {
    pages[currentPage].handleTouch();
  }
}

extern boolean checkTouch(TSPoint p) {

}
